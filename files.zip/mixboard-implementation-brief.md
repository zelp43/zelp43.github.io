# Mixboard renderer — implementation brief

## What this is

Attached is `mixboard-home-v4.html` — a working static mockup of the Mixboard home screen (a macOS Electron audio mixer, general system-audio routing: per-app/hardware input channels with EQ, echo, mute/solo, and Main/Aux/Monitor output routing, plus a recorder). It is the **authoritative visual and interaction spec** — colors, spacing, typography, component shapes, and all current interactive behaviors (draggable faders, draggable echo-intensity knob, toggle buttons, format switch, record timer) should be reproduced pixel-for-pixel, not reinterpreted.

## Task

Reimplement this screen as strict, typed **TypeScript** for an Electron renderer process. No JavaScript files — `.ts` only, `strict: true` in `tsconfig`, no `any` except where genuinely unavoidable (document with a comment if so).

Keep it framework-free (vanilla DOM/TS), matching the rest of the codebase's conventions — do not introduce React/Vue/etc. unless there's a concrete reason to and you flag it as a deviation before proceeding.

Reuse the existing CSS from the mockup as a separate `.css` file rather than reimplementing styles inline in TS — the visual design is already finished and approved.

## Structure

Organize into logical modules rather than one large file, roughly:

- `types.ts` — shared domain types (see below)
- `components/channelStrip.ts` — one input channel (select, EQ, echo, fader, meter, route buttons, solo/mute)
- `components/outputBus.ts` — one output bus (Main/Aux/Monitor: label, device select, fader, meter, mute)
- `components/recordingPanel.ts` — record button, timer, format toggle, save-location control
- `components/knob.ts` — reusable rotary control (used for EQ bands and echo intensity), draggable, emits a typed change event
- `components/fader.ts` — reusable vertical fader + level meter pairing, draggable, emits a typed change event
- `app.ts` — assembles the above into the full screen and owns top-level state
- `preload.ts` / `mixboardApi.d.ts` — typed surface for the eventual native audio engine (see IPC section)

## Domain types (starting point — adjust as needed)

```ts
type RouteTarget = 'main' | 'aux' | 'monitor';
type RecordingFormat = 'wav' | 'mp3';
type OutputDeviceId = string; // resolved from the OS device list at runtime

interface EQBand {
  band: 'high' | 'mid' | 'low';
  gainDb: number; // -12..+12
}

interface ChannelState {
  id: string;
  source: string;          // currently selected input option, e.g. "Microphone"
  availableSources: string[];
  eq: EQBand[];
  echoEnabled: boolean;
  echoIntensity: number;    // 0..100
  faderDb: number;
  routes: Record<RouteTarget, boolean>; // a channel can be sent to more than one bus at once
  solo: boolean;
  mute: boolean;
  levelDb: number;          // for the meter — comes from the audio engine, not decorative CSS
}

interface OutputBusState {
  id: RouteTarget;
  label: string;
  deviceId: OutputDeviceId;
  availableDevices: { id: OutputDeviceId; label: string }[];
  faderDb: number;
  mute: boolean;
  levelDb: number;
}

interface RecordingState {
  isRecording: boolean;
  format: RecordingFormat;
  savePath: string;
  elapsedSeconds: number;
  fileName: string;
}
```

## Behavior to preserve exactly

- Faders: click-drag on the cap moves it within the track and updates the printed dB value live. Preserve the drag math from the mockup's `<script>` block (percent-of-track → dB mapping), but the resulting value should flow through a typed `onChange(db: number)` callback rather than just mutating the DOM.
- Echo intensity knob: same drag-to-rotate behavior as the mockup, 0–100%, dimmed (`opacity` state, not just a CSS class name necessarily — just preserve the visual dimming) when echo is off.
- Route buttons (Main/Aux/Mon) are independent toggles — a channel can be active on more than one simultaneously. "Mon" gets the teal active state; Main/Aux get the dark active state, matching the mockup.
- Solo/Mute/format toggle behavior matches the mockup's click handlers.
- Record button starts/stops a timer formatted `HH:MM:SS`.

## IPC surface (stub for now, typed for later)

The actual audio engine (CoreAudio process taps, mixing, EQ, echo DSP) doesn't exist yet — this UI currently just needs to compile and run standalone with realistic mock data. Structure the code so wiring in the real thing later is a drop-in, not a rewrite:

- Define a `MixboardApi` interface in `mixboardApi.d.ts` with methods like `setChannelGain(channelId, db)`, `setChannelEQ(channelId, band, db)`, `setEchoIntensity(channelId, pct)`, `setChannelRoute(channelId, target, enabled)`, `setOutputDevice(busId, deviceId)`, `startRecording()`, `stopRecording()`, `setRecordingPath(path)`, and a subscription method like `onLevelUpdate(cb: (channelId: string, db: number) => void)`.
- For now, implement a `mockMixboardApi.ts` that satisfies this interface: fake devices lists, a `setInterval`-driven level generator (can port the existing CSS keyframe values as the fake data source) instead of real audio, and no-ops for record/device calls that just update local state and log to console.
- `app.ts` should depend only on the `MixboardApi` interface, not on the mock directly, so swapping in a real `electronMixboardApi.ts` (backed by actual IPC to a main-process audio engine) later is a one-line change.

## Recording save-location control

The "Change…" button should call a typed `pickSaveDirectory(): Promise<string | null>` on the API (mocked for now as a resolved fake path; in the real app this will call Electron's `dialog.showOpenDialog` from the main process over IPC). Update `savePath` in state and the displayed path on a successful pick; do nothing on cancel.

## Explicitly out of scope for this pass

- No real audio processing, no real device enumeration, no real file I/O.
- No new visual design decisions — if something in the mockup is ambiguous, ask rather than improvise.
